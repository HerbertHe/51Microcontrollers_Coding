#include "reg52.h"

typedef unsigned char u8;
typedef unsigned int u16;
#define TIME 200
sbit INA=P1^0;
sbit INB=P1^1;
sbit INC=P1^2;
sbit IND=P1^3;

void delay(u16 i)
{
	while(i--);
}

void main()
{
	P1=0x00;
	
	while(1)
	{
		INA=1;
		INB=0;
		INC=1;
		IND=1;
		delay(TIME);
		INA=0;
		INB=1;
		INC=1;
		IND=1;
		delay(TIME);
		INA=1;
		INB=1;
		INC=1;
		IND=0;
		delay(TIME);
		INA=1;
		INB=1;
		INC=0;
		IND=1;
		delay(TIME);
	}
}
//A+->A-->B+->B-          xunhuan wei gaodianwei xiangwei cha
#include "reg52.h"

typedef unsigned char u8;
typedef unsigned int u16;

u8 code smgduanxuan[16]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};

sbit A0=P2^2;
sbit A1=P2^3;
sbit A2=P2^4;

void delay(u16 i)
{
	while(i--);
}

void weixuan()
{
	u8 i;
	for(i=0;i<8;i++)
	{
		switch(i)
		{
			case 0:A0=0;A1=0;A2=0;break;
			
			case 1:A0=1;A1=0;A2=0;break;
			
			case 2:A0=0;A1=1;A2=0;break;
			
			case 3:A0=1;A1=1;A2=0;break;
			
			case 4:A0=0;A1=0;A2=1;break;
			
			case 5:A0=1;A1=0;A2=1;break;
			
			case 6:A0=0;A1=1;A2=1;break;
			
			case 7:A0=1;A1=1;A2=1;break;
			
		}
		
		P0=smgduanxuan[i];
		
		delay(100);
		
		P0=0x00;
		
	}
}

void main()
{
	while(1)
	{
		weixuan();
	}
}
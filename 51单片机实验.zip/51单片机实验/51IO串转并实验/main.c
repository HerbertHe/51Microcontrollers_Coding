#include "reg52.h"
#include "intrins.h"

typedef unsigned char u8;
typedef unsigned int u16;

#define GPIO_LED P0

sbit RCLK1=P3^5;
sbit SER=P3^4;
sbit SRCLK=P3^6;

void out74HC595(u8 data1)
{
	u8 i;
	for(i=0;i<8;i++)
	{
		SER=data1>>7;//liyong >> buling
		data1<<=1;
		SRCLK=0;
		_nop_();
		SRCLK=1;
	}
	RCLK1=0;
	_nop_();
	RCLK1=1;
}

void main()
{
	while(1)
	{
		out74HC595(0x10);
	}
}
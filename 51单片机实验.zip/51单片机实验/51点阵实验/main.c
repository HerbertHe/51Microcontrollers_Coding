#include "reg52.h"
#include "intrins.h"

typedef unsigned char u8;
typedef unsigned int u16;

#define LEDlie P0
#define LEDhang P2
//01111111  10111111  11011111  11101111  11110111  11111011  11111101  11111110
u8 code lie[8]={0x7f,0xbf,0xdf,0xef,0xf7,0xfb,0xfd,0xfe};

u8 code hang[8]={0x66,0xff,0xff,0xff,0x7e,0x3c,0x18,0x00};

void delay(u16 i)
{
	while(i--);
}
void main()
{
	u8 i;
	while(1)
	{
		for(i=0;i<8;i++)
		{
			LEDlie=lie[i];
			LEDhang=hang[i];
		}
	}
}
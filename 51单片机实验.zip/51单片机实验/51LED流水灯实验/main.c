#include "reg52.h"
#include "intrins.h"
#define LED P0     //dingyi a group hongdingyi

typedef unsigned char u8;
typedef unsigned int u16;


void delay(u16 i)
{
	while(i--);
}


void main()    
{
	while(1)
	{
		u8 i;
		LED=0x01;  //0000 0001
		/*for(i=0;i<8;i++)            //how running water light run,go into left i space
		{
			LED=(0x01<<i);//go into left i space
			delay(50000);
		}*/
		
		for(i=0;i<8;i++)                
		{
			LED=_cror_(LED,1);           //cro right (bianliangdezhi,weishu)
			delay(50000);
		}
		
		for(i=0;i<7;i++)
		{
			LED=_crol_(LED,1);           //cro left (bianliangdezhi,weishu) 1000 0000
		  delay(50000);
		}
	}
}










#include "reg52.h"

typedef unsigned char u8;  //type def  leidingyi
typedef unsigned int u16;

sbit LED1=P0^0;
sbit LED2=P0^1;
sbit LED3=P0^2;
sbit LED4=P0^3;
sbit LED5=P0^4;
sbit LED6=P0^5;
sbit LED7=P0^6;
sbit LED8=P0^7;

void delay(u16 i) //program in keil,hanshu must be written behind the main,or it can not run in main 
{
	while(i--);
}

void main()
{
	while(1)
	{
		LED1=1;
		delay(50000);
		LED1=0;
		delay(50000);
		LED2=0;
		delay(50000);
		LED2=1;
		delay(50000);
		LED3=1;
		delay(50000);
		LED3=0;
		delay(50000);
		LED4=0;
		delay(50000);
		LED4=1;
		delay(50000);
		LED5=1;
		delay(50000);
		LED5=0;
		delay(50000);
		LED6=0;
		delay(50000);
		LED6=1;
		delay(50000);
		LED7=1;
		delay(50000);
		LED7=0;
		delay(50000);
		LED8=0;
		delay(50000);
		LED8=1;
		delay(50000);	
	}
}




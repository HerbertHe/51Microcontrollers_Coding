#include "reg52.h"

typedef unsigned char u8;
typedef unsigned int u16;

sbit LED=P0^0;
sbit KEY=P1^0;

void delay(u16 i)
{
	while(i--);
}

void keypros()                                        //software xiaodou
{
	if(KEY==0)                                          //xiaodou panduan
	{
		delay(1000);
		if(KEY==0)                                        //panduan again
		{
			LED=~LED;                                       //action
		}
		while(!KEY);                                      //songkai panduan xunhuan
	}
}

void main()
{
	LED=0;
	while(1)
	{
		keypros();
	}
}
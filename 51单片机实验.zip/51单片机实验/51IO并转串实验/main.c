#include "reg52.h"
#include "intrins.h"

typedef unsigned char u8;
typedef unsigned int u16;

#define GPIO_LED P0

sbit IN_PL=P1^6;
sbit IN_Data=P1^7;
sbit SCK=P3^6;

u8 Read74HC165()
{
	u8 indata=0;
	u8 i;
	IN_PL=0;//didianping zhiru
	_nop_();//yanshi yige zhou qi
	IN_PL=1;//gaodianping yiwei
	_nop_();//zhiqian duqu jiu baocunzai jicunqi zhong
	for(i=0;i<8;i++)
	{
		indata=indata<<1;
		SCK=0;
		_nop_();
		indata|=IN_Data;
		SCK=1;
		return indata;
	}
}


void main()
{
	u8 value11=0x00;
	value11=Read74HC165();
	while(1)
	{
		if(value11!=0xff)
			GPIO_LED=~value11;
	}
}
#include "reg52.h"

typedef unsigned char u8;
typedef unsigned int u16;

sbit moto=P1^5;

void delay(u16 i)
{
	while(i--);
}

void main()
{
	u8 i;
	for(i=0;i<100;i++)
	{
		moto=1;
		delay(5000);
	}
	moto=0;
	while(1)
	{
		
	}
}
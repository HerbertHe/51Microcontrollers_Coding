#include "reg52.h"

sbit LED1=P0^0;
sbit LED2=P0^1;  //s b i t duankoudingyi
sbit LED3=P0^2;
sbit LED4=P0^3;
sbit LED5=P0^4;
sbit LED6=P0^5;
sbit LED7=P0^6;
sbit LED8=P0^7;

void main()
{
	while(1)
	{
		LED1=1;  //1 up dianping
		LED2=1;
		LED3=1;
		LED4=1;
		LED5=1;
		LED6=1;
		LED7=1;
		LED8=1;
	}
}